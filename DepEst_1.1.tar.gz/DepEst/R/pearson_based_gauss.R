##############################################################
## This function finds Pearson Based Gaussian Estimator.    ##
##############################################################

pearson.based.gauss <- function(dataset, cop.transform = TRUE, parallel=FALSE){
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	# replace the NA values with the avg value of the other values:
	dataset <- replace.NAs.with.avg(dataset)

	if (cop.transform)
		dataset <- copula.transform(dataset);
	
	ngenes <- nrow(dataset);
	nsamples <- ncol(dataset);

	dataset.tra <- t(dataset); # because cor func needs one gene corresponds to one column.

	if (parallel)
	{
		flag = 0
		num.work <- getDoParWorkers()
		if ( !(exists("cls.pr", envir=.GlobalEnv)) ) {
			cls.pr <- setupCls(use.cores=(num.work-1))
			clusterCall(cls.pr, eval, library(DepEst))
			flag = 1
		}

		if(ngenes < 10000)
			warning("It is not recommended to run PBG as parallel, when the number of genes is small (e.g. less than 10,000). Still PBG will be run as parallel.")
		pear.cor.val <- matrix(parRapply(cls.pr, dataset, cor, dataset.tra, method="pearson"), ngenes, ngenes)

		if (flag==1) 
			stopCluster(cls.pr)
	}
	else
		pear.cor.val <- cor(dataset.tra, method="pearson");

	# if the joint dist is normal, corr can be converted to MI as:
	pear.cor.val.sq <- pear.cor.val^2;
  	pear.cor.val.sq[which(pear.cor.val.sq >= 1)] <- 0.999999
	mim <- abs( -0.5*log(1-pear.cor.val.sq) )
	diag(mim)<-0
	abs(mim)
}
