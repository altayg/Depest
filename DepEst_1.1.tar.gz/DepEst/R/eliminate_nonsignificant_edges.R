eliminate.nonsignificant.edges <- function(mim, Ic=0, method = 1){
	genenum = nrow(mim)
	if(Ic == 0){
		if(method == 1){
			mim.vec <- matrix(mim, genenum *genenum , 1);
			sorted.vec <- sort(mim.vec)
			cut.off.index <- trunc(genenum * genenum * 0.2)  # eliminate 10% of the mim matrix. *2 because of symmetric matrix.
			Ic <- sorted.vec[cut.off.index]	
		}
		else
			Ic <- mean(mim[upper.tri(mim)])
	}
	mim[mim < Ic] <-0 # nonsignificant values are eliminated.
	mim
}
