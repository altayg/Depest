make.mim.sym <- function(mim) 
{
	ngenes <- nrow(mim);
	for(i in 2:ngenes)
		for(j in 1:(i-1))
			mim[i,j] = mim[j,i]

	mim
}