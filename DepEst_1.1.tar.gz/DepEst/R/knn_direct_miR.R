knn.direct.miR <- function(dataset, cop.transform = TRUE, K=0)
{
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	# replace the NA values with the avg value of the other values:
	dataset <- replace.NAs.with.avg(dataset)

	if (cop.transform)
		dataset <- copula.transform(dataset);
	

	ngenes <- nrow(dataset);
	nsamples <- ncol(dataset);
	mim <- matrix(0, ngenes, ngenes);

	if (K == 0) { K <- trunc(0.4*0.4*nsamples)+1; }
	out<-.C("knnC", as.double(dataset), as.integer(ngenes), as.integer(nsamples),as.integer(K), x=as.double(matrix(0,ngenes,ngenes)), PACKAGE="DepEst");
	mim <- matrix(out$x, ngenes, ngenes)
	abs(mim)
}
