hhgR <- function(dataset, cop.transform = TRUE)
{
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	# replace the NA values with the avg value of the other values:
	dataset <- replace.NAs.with.avg(dataset)

	if (cop.transform)
		dataset <- copula.transform(dataset);
	

	ngenes <- nrow(dataset);
	nsamples <- ncol(dataset);
	mim <- matrix(0, ngenes, ngenes);

	out<-.C("hhgC", as.double(dataset), as.integer(ngenes), as.integer(nsamples), x=as.double(matrix(0,ngenes,ngenes)), PACKAGE="DepEst");
	mim <- matrix(out$x, ngenes, ngenes)
	abs(mim)
}
