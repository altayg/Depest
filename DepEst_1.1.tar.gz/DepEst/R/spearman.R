###############################################################
## This function finds Spearman correlation coefficient.     ##
############# #################################################

spearman <- function(dataset, cop.transform = TRUE, parallel=FALSE){
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	# replace the NA values with the avg value of the other values:
	dataset <- replace.NAs.with.avg(dataset)

	if (cop.transform)
		dataset <- copula.transform(dataset);
	
	ngenes <- nrow(dataset);
	nsamples <- ncol(dataset);

	# spearman rank correlation coefficient calculation:
	dataset.tra <- t(dataset); # because cor func needs one gene corresponds to one column.
	
	if (parallel)
	{
		flag = 0
		num.work <- getDoParWorkers()
		if ( !(exists("cls.pr", envir=.GlobalEnv)) ) {
			cls.pr <- setupCls(use.cores=(num.work-1))
			clusterCall(cls.pr, eval, library(DepEst))
			flag = 1
		}

		if(ngenes < 10000)
			warning("It is not recommended to run SCC as parallel, when the number of genes is small (e.g. less than 10,000). Still SCC will be run as parallel.")
		spe.cor.val <- matrix(parRapply(cls.pr, dataset, cor, dataset.tra, method="spearman"), ngenes, ngenes)

		if (flag==1) 
			stopCluster(cls.pr)
	}
	else
		spe.cor.val <- cor(dataset.tra, method="spearman");

	diag(spe.cor.val)<-0
	abs(spe.cor.val)
}
