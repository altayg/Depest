discretize.datasetR <- function(dataset, binnum=trunc(sqrt(ncol(dataset))), disc.method="eq.freq")
{
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	# replace the NA values with the avg value of the other values:
	dataset <- replace.NAs.with.avg(dataset)

	ngenes <- nrow(dataset);
	nsamples <- ncol(dataset);
	bins.of.dataset <- matrix(0, ngenes, nsamples);

	disc = 1;
	if (disc.method == "eq.wid"){
		disc = 2;
	}

	out<-.C("discrete_datasetC", as.double(dataset), as.integer(ngenes), as.integer(nsamples), as.integer(binnum), as.integer(disc), x=as.integer(matrix(0,ngenes,nsamples)), PACKAGE="DepEst");
	bins.of.dataset <- matrix(out$x, ngenes, nsamples)
	bins.of.dataset
}

