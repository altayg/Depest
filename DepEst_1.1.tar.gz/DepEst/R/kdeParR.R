kdeParR <- function(dataset, cop.transform = TRUE, bandwidth=0)
{
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}
	
	# replace the NA values with the avg value of the other values:
	dataset <- replace.NAs.with.avg(dataset)

	if (cop.transform)
		dataset <- copula.transform(dataset);
	

	flag = 0
	num.work <- getDoParWorkers()
	if ( !(exists("cls.pr", envir=.GlobalEnv)) ) {
		cls.pr <- setupCls(use.cores=(num.work-1))
		clusterCall(cls.pr, eval, library(DepEst))
		flag = 1
	}

	ngenes <- nrow(dataset);
	nsamples <- ncol(dataset);
	mim <- matrix(0, ngenes, ngenes);
	
 	out<-foreach(i = 1: num.work, .packages=c("DepEst"), .combine="rbind") %dopar% {
		id.info <- return.id.info(ngenes, num.work, i)
		out.loc <- .C("p_kdeC", as.double(dataset), as.integer(ngenes), as.integer(nsamples), as.double(bandwidth), as.integer(i), as.integer(num.work), x=as.double(matrix(0,id.info$rows.num,ngenes)), PACKAGE="DepEst");
		mim.loc <- matrix(out.loc$x,id.info$rows.num,ngenes)
	}
	mim <- matrix(out, ngenes, ngenes)
	# make matrix mim symmetric:
	mim <- make.mim.sym(mim)

	if (flag==1) 
		stopCluster(cls.pr)

	abs(mim)
}


