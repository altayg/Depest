miller.madowParR <- function(dataset, cop.transform = TRUE, binnum=trunc(sqrt(ncol(dataset))), disc.method="eq.freq")
{
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	# replace the NA values with the avg value of the other values:
	dataset <- replace.NAs.with.avg(dataset)

	if (cop.transform)
		dataset <- copula.transform(dataset);
	

	flag = 0
	num.work <- getDoParWorkers()
	if ( !(exists("cls.pr", envir=.GlobalEnv)) ) {
		cls.pr <- setupCls(use.cores=(num.work-1))
		clusterCall(cls.pr, eval, library(DepEst))
		flag = 1
	}

	ngenes <- nrow(dataset);
	nsamples <- ncol(dataset);
	mim <- matrix(0, ngenes, ngenes);

 	# first obtain the individual entropies
	bins.of.dataset <- discretize.datasetParR(dataset, binnum, disc.method)
	out<-foreach(i = 1: num.work, .packages=c("DepEst"), .combine="c") %dopar% {
		id.info <- return.id.info(ngenes, num.work, i)
		out.loc <- .C("p_mm_indEntC", as.integer(bins.of.dataset[id.info$firstrow:id.info$lastrow,]), as.integer(ngenes), as.integer(nsamples), as.integer(binnum), as.integer(id.info$rows.num), x=as.double(matrix(0,id.info$rows.num,1)), PACKAGE="DepEst");
		indiv.ent.loc <- matrix(out.loc$x,id.info$rows.num,1)
	}
	indiv.ent <- matrix(out, ngenes, 1)

	# then obtain the MI values:
	out<-foreach(i =1: num.work, .packages=c("DepEst"), .combine="rbind") %dopar% {
		id.info <- return.id.info(ngenes, num.work, i)
		out.loc <- .C("p_mm_miC", as.integer(bins.of.dataset), as.integer(ngenes), as.integer(nsamples), as.integer(binnum), as.integer(i), as.integer(num.work), as.double(indiv.ent), x=as.double(matrix(0,id.info$rows.num,ngenes)), PACKAGE="DepEst");
		mim.loc <- matrix(out.loc$x,id.info$rows.num,ngenes)
	}
	mim <- matrix(out, ngenes, ngenes)
	# make matrix mim symmetric:
	mim <- make.mim.sym(mim)

	if (flag==1) 
		stopCluster(cls.pr)

	abs(mim)
}
