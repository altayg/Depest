significanceMTCtest <- function(dataset, estimator= "scc", alpha=0.01, itnum=10, methodsig="BH", cop.transform=TRUE, num.of.bins=trunc(sqrt(ncol(dataset))), disc.method="eq.freq", bandwidth = 0, spline.order=2, num.of.neighbours = 0, parallel=FALSE)
{
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	################# 
	res <- significancePERMtest(dataset, estimator, alpha, itnum, cop.transform, num.of.bins, disc.method, bandwidth, spline.order, num.of.neighbours, parallel) 	
	################# 
	mim <- res$mim
	### FDR process starts

	Inew <- mim
	ngene<- ncol(mim)

	MIs <- mim[upper.tri(mim, diag = FALSE)]

	vg <- res$vg

	pMI <- matrix(c(1),ngene,ngene)
	sum_vg <- sum(vg)
	vgnum <- length(vg)
	E <- length(MIs)

	pvg <- c()
	max_vg <- max(vg)

	for(i in 1: (ngene-1)) 
		for(ix in (i+1):ngene)
		{
			j <- 0
			ii <-	 1

			if(max_vg <= mim[i,ix])
			{
				pMI[i,ix] <- 0 
 				pMI[ix,i] <- 0 
			}
	
			if(max_vg > mim[i,ix])
			{
				ind <- which( vg > mim[i,ix])
				LL <- length(vg)
				ptemp <- length(ind)/LL
				pMI[i,ix] <- ptemp
				pMI[ix,i] <- ptemp
			} 
		}

	p_val <- pMI[upper.tri(pMI, diag = FALSE)]

	padj <- p.adjust(p_val,  method = methodsig)
	MIedges <- MIs 
	for (jj in 1:E) { if(padj[jj] > alpha) MIs[jj] <- 0 }  	#eliminate nonsignificant MIs 

	Inew[upper.tri(Inew)] <- MIs
	txI<-t(Inew)
	Inew[lower.tri(Inew)] <- txI[lower.tri(txI)]
	diag(Inew) <- 0

	pMIadj <- matrix(c(1),ngene,ngene)
	pMIadj[upper.tri(pMIadj)] <- padj

	res <- new.env()  
	assign("I0", res$I0, envir=res)
	assign("vg", res$vg, envir=res)
	assign("padj", padj, envir=res)
	assign("p_val", p_val, envir=res)
	assign("pMIadj", padj, envir=res)
	assign("pMI", p_val, envir=res)
	assign("Inew", Inew, envir=res)
	assign("mim", mim, envir=res)
	assign("MIedges", MIedges, envir=res)

	res   
} 

