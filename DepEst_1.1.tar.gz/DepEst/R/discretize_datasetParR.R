discretize.datasetParR <- function(dataset, binnum=trunc(sqrt(ncol(dataset))), disc.method="eq.freq")
{
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	# replace the NA values with the avg value of the other values:
	dataset <- replace.NAs.with.avg(dataset)

	flag = 0
	num.work <- getDoParWorkers()
	if ( !(exists("cls.pr", envir=.GlobalEnv)) ) {
		cls.pr <- setupCls(use.cores=(num.work-1))
		clusterCall(cls.pr, eval, library(DepEst))
		flag = 1
	}

	ngenes <- nrow(dataset);
	nsamples <- ncol(dataset);
	bins.of.dataset <- matrix(0, ngenes, nsamples);

	disc = 1;
	if (disc.method == "eq.wid"){
		disc = 2;
	}
	
	out<-foreach(i =1: num.work, .packages=c("DepEst"), .combine="rbind") %dopar% {
		id.info <- return.id.info(ngenes, num.work, i)
		out.loc <- .C("p_discrete_datasetC", as.double(dataset[id.info$firstrow:id.info$lastrow,]), as.integer(ngenes), as.integer(nsamples), as.integer(binnum), as.integer(disc), as.integer(id.info$rows.num), x=as.integer(matrix(0,id.info$rows.num,nsamples)), PACKAGE="DepEst");
		bins.of.dataset.loc <- matrix(out.loc$x,id.info$rows.num,nsamples)
	}
	bins.of.dataset <- matrix(out, ngenes, nsamples)

	if (flag==1) 
		stopCluster(cls.pr)

	bins.of.dataset
}
