replace.NAs.with.avg <- function(dataset)
{
	ngenes <- nrow(dataset);
	for(g in 1:ngenes){
		# replace the NA values with the avg value of the other values:
		##########################################################
		samples.of.g=dataset[g,];			
		without.NA <- samples.of.g[which( is.na(samples.of.g) == FALSE)]
		avg.val <- mean(without.NA);
		samples.of.g[which(is.na(samples.of.g) == TRUE)] <- avg.val;
		dataset[g,] = samples.of.g;
		##########################################################
	}
	dataset
}
