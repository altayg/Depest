setupCls <- function(use.cores=0, cls.list=NULL){

	if ( exists("cls.pr", envir=.GlobalEnv) ) {
		stopCluster(cls.pr)
		objs <- ls(pos = ".GlobalEnv")
		rm(list = objs[grep("cls.pr", objs)], pos = ".GlobalEnv")
	}

	if(!(is.null(cls.list)))
		cls.pr <- makeCluster(cls.list)
	else{
		core.num <- detectCores()
		if (use.cores > core.num){
			if (core.num > 1){
				warning("There are ", core.num, " cores in this machine. By default ", core.num-1, " of them will be used.")
				use.cores = core.num - 1
			}
			else{
				warning("There is only one core in this machine. Only, it will be used.")
				use.cores = 1
			}
			
		}
		if (use.cores == 0)
			use.cores = core.num - 1
		if (use.cores < 1)
			use.cores = 1
		
		# assign("cls.pr", makeCluster(use.cores), envir = .GlobalEnv)
		cls.pr <-  makeCluster(use.cores)
	}

	registerDoSNOW(cls.pr)
	clusterCall(cls.pr, eval, library(DepEst))
	cls.pr
}
