b.splineR <- function(dataset, cop.transform = TRUE, binnum=0, spline.order=1)
{
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	# replace the NA values with the avg value of the other values:
	dataset <- replace.NAs.with.avg(dataset)

	if (cop.transform)
		dataset <- copula.transform(dataset);


	ngenes <- nrow(dataset);
	nsamples <- ncol(dataset);
	mim <- matrix(0, ngenes, ngenes);

	if (binnum == 0) binnum <- trunc(sqrt(nsamples));

	out<-.C("b_splineC", as.double(dataset), as.integer(ngenes), as.integer(nsamples), as.integer(binnum), as.integer(spline.order),x=as.double(matrix(0,ngenes,ngenes)), PACKAGE="DepEst");
	mim<-matrix(out$x, ngenes, ngenes)
	abs(mim)
}
