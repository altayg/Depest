obtain.mim <- function(dataset, estimator="scc", cop.transform = TRUE, num.of.bins=trunc(sqrt(ncol(dataset))), disc.method="eq.freq", bandwidth = 0, spline.order=2, num.of.neighbours = 0, parallel=FALSE)
{

	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}
	dataset <- replace.NAs.with.avg(dataset)

	genenum <- nrow(dataset); # rows are genes in the dataset.
	samplenum <- ncol(dataset); # cols are samples in the dataset.
	gnames<-rownames(dataset);
	snames<-colnames(dataset);
	
	mim <- matrix(0, genenum, genenum );
	rownames(mim) <- gnames
	colnames(mim) <- gnames
	
	if (parallel){ # the chosen estimator should be run on several nodes:
		
		############################################
		# setupCls() should be called from outside #
		############################################
		
		if(estimator == "pcc") # Pearson Correlation Coefficient
			mim <- pearson(dataset, cop.transform, parallel)
		else if(estimator == "scc") # Spearman Correlation Coefficient
			mim <- spearman(dataset, cop.transform, parallel)
		else if(estimator == "pbg") # Pearson-Based Gaussian Estimator
			mim <- pearson.based.gauss(dataset, cop.transform, parallel)
		else if(estimator == "sbg") # Spearman-Based Gaussian Estimator
			mim <- spearman.based.gauss(dataset, cop.transform, parallel)
		else if(estimator == "ppcn") # n-th Order Pearson Correlation Coefficient
			mim <- ppcn(dataset, cop.transform, parallel)
		else if(estimator == "miller.madow") # Miller-Madow Estimator
			mim <- miller.madowParR(dataset, cop.transform, num.of.bins, disc.method)
		else if(estimator == "chao.shen") # Chao-Shen Estimator
			mim <- chao.shenParR(dataset, cop.transform, num.of.bins, disc.method)
		else if(estimator == "b.spline") # B-Spline Estimator
			mim <- b.splineParR(dataset, cop.transform,  num.of.bins, spline.order)
		else if(estimator == "hhg") # Heller, Heller, Gorfine Estimator
			mim <- hhgParR(dataset, cop.transform)
		else if(estimator == "kde") # Kernel Density Estimator
			mim <- kdeParR(dataset, cop.transform,  bandwidth)
		else if(estimator == "knn") # K-Nearest Neighbourhood Estimator
			mim <- knn.direct.miParR(dataset, cop.transform,  num.of.neighbours)
		else
			stop("Unknown method")
		# if (exists("cls.pr")) stopCluster(cls.pr)
	}
	else { # the chosen estimator should be run on only one node:
		if(estimator == "pcc") # Pearson Correlation Coefficient
			mim <- pearson(dataset, cop.transform)
		else if(estimator == "scc") # Spearman Correlation Coefficient
			mim <- spearman(dataset, cop.transform)
		else if(estimator == "pbg") # Pearson-Based Gaussian Estimator
			mim <- pearson.based.gauss(dataset, cop.transform)
		else if(estimator == "sbg") # Spearman-Based Gaussian Estimator
			mim <- spearman.based.gauss(dataset, cop.transform)
		else if(estimator == "ppcn") # n-th Order Pearson Correlation Coefficient
			mim <- ppcn(dataset, cop.transform)
		else if(estimator == "miller.madow") # Miller-Madow Estimator
			mim <- miller.madowR(dataset, cop.transform,  num.of.bins, disc.method)
		else if(estimator == "chao.shen") # Chao-Shen Estimator
			mim <- chao.shenR(dataset, cop.transform,  num.of.bins, disc.method)
		else if(estimator == "b.spline") # B-Spline Estimator
			mim <- b.splineR(dataset, cop.transform,  num.of.bins, spline.order)
		else if(estimator == "hhg") # Heller,Heller, Gorfine Estimator
			mim <- hhgR(dataset, cop.transform)
		else if(estimator == "kde") # Kernel Density Estimator 
			mim <- kdeR(dataset, cop.transform,  bandwidth)
		else if(estimator == "knn") # K-Nearest Neighbourhood Estimator
			mim <- knn.direct.miR(dataset, cop.transform,  num.of.neighbours)
		else 
			stop("Unknown method")
	}
	mim
}

