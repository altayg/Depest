###############################################################
## This function applies copula transform to dataset.        ##
############# #################################################

copula.transform <- function(dataset){
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	sample.num <- ncol(dataset)
	gene.num <- nrow(dataset)
	dataset.cop <- matrix(0,gene.num,sample.num)
	for (i in 1:gene.num){
		dataset.cop[i,] <- matrix( rank(dataset[i,], ties.method= "first"), ncol = sample.num) # index of the values in asc order when they are sorted.
	}
	dataset.cop <- (dataset.cop-0.5) / sample.num; # sample.num is the largest element in the ranked values
	rownames(dataset.cop) <- rownames(dataset)
	colnames(dataset.cop) <- colnames(dataset)     
	dataset.cop 
}
