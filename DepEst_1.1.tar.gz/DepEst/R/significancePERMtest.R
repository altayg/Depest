significancePERMtest <- function(dataset, estimator= "scc", alpha=0.01, itnum=10, cop.transform=TRUE, num.of.bins=trunc(sqrt(ncol(dataset))), disc.method="eq.freq", bandwidth = 0, spline.order=2, num.of.neighbours = 0, parallel=FALSE)   
{
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}
	gnames<-rownames(dataset)
	a<-as.matrix(dataset)
	numbrow <- nrow(a)
	numbcol <- ncol(a)
	
	numbdataset <- itnum   #number of exp random matrices	
	v<-c()    #final MI vector 

	for(i in 1:numbdataset)
	{
		expshufled<-matrix(sample(a), numbrow,numbcol) 			##randomize all elements
	
		mim <- obtain.mim(dataset, estimator, cop.transform, num.of.bins, disc.method, bandwidth, spline.order, num.of.neighbours, parallel)

		c<-mim
		ctry<-c
		ccc<-ctry[upper.tri(ctry)]
		ccc<-ccc[ccc!=0]

		t1<-as.vector(ccc)
		v<-c(v,t1)
	} #end for i
	vg<-sort(v)

	### obtain MIM matrix
	
	mim <- obtain.mim(dataset, estimator, cop.transform, num.of.bins, disc.method, bandwidth, spline.order, num.of.neighbours, parallel)

	rownames(mim) <-gnames
	colnames(mim) <-gnames

	## from alpha, MI threshold estimation
	L <- length(vg)
	temp <- ceiling((1-alpha)*L)
	I0 <- vg[temp]
	#############
	Inew <- mim
	Inew[Inew < I0] <-0 

	res <- new.env()  
	assign("I0", I0, envir=res)
	assign("vg", vg, envir=res)
	assign("Inew", Inew, envir=res)
	assign("mim", mim, envir=res)

	res   

} 
