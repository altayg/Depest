return.id.info <- function(ngenes, num.work, i)
{
	chunksize = trunc(ngenes/num.work)
	residual = ngenes%%num.work
	rows.num = chunksize 

	firstrow = (i - 1) * chunksize + 1
	lastrow = firstrow + chunksize - 1
	if ( residual >= i ) {
	   firstrow = firstrow + i - 1;
	   lastrow = lastrow + i;
	   rows.num = rows.num + 1
	}
	else {
		firstrow = firstrow + residual;
		lastrow = lastrow + residual;
	}  

	id.info <- new.env()  
	assign("firstrow", firstrow, envir=id.info)
	assign("lastrow", lastrow, envir=id.info)
	assign("rows.num", rows.num, envir=id.info)
	id.info
}
