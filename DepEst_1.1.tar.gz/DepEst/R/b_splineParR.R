b.splineParR <- function(dataset, cop.transform = TRUE, binnum=0, spline.order=1)
{
	if (is.data.frame(dataset)){
		dataset <- as.matrix(dataset);
		mode(dataset) <- "double"
	}

	# replace the NA values with the avg value of the other values:
	dataset <- replace.NAs.with.avg(dataset)

	if (cop.transform)
		dataset <- copula.transform(dataset);

	flag = 0
	num.work <- getDoParWorkers()
	if ( !(exists("cls.pr", envir=.GlobalEnv)) ) {
		cls.pr <- setupCls(use.cores=(num.work-1))
		clusterCall(cls.pr, eval, library(DepEst))
		flag = 1
	}

	ngenes <- nrow(dataset);
	nsamples <- ncol(dataset);
	mim <- matrix(0, ngenes, ngenes);

	if (binnum == 0) binnum <- trunc(sqrt(nsamples));

 	# first obtain the array "member"
	out<-foreach(i =1: num.work, .packages=c("DepEst")) %dopar% {
		ii <- i
		id.info <- return.id.info(ngenes, num.work, ii)
		out.loc <- .C("p_bs_memberC", as.double(dataset[id.info$firstrow:id.info$lastrow,]), as.integer(ngenes), as.integer(nsamples), as.integer(binnum), as.integer(spline.order), as.integer(i), as.integer(num.work), x=as.double(array(0, dim=c(binnum,nsamples,ngenes))), PACKAGE="DepEst");
		member.loc <- array(out.loc$x, dim=c(binnum,nsamples,ngenes))
	}
	out.act <- array(0, dim=c(binnum,nsamples,ngenes))
	for(i in 1:num.work)	out.act <- out.act + out[[i]];
	member <- out.act
	
	# second obtain the individual entropies
	out<-foreach(i =1: num.work, .packages=c("DepEst"), .combine="c") %dopar% {
		id.info <- return.id.info(ngenes, num.work, i)
		out.loc <- .C("p_bs_indEntC", as.integer(ngenes), as.integer(nsamples), as.integer(binnum), as.integer(spline.order), as.integer(id.info$rows.num), as.double(member[,,id.info$firstrow:id.info$lastrow]), x=as.double(matrix(0,id.info$rows.num,1)), PACKAGE="DepEst");
		indiv.ent.loc <- matrix(out.loc$x, id.info$rows.num, 1)
	}
	indiv.ent <- matrix(out, ngenes, 1)

	# then obtain the MI values:
	out<-foreach(i =1: num.work, .packages=c("DepEst"), .combine="rbind") %dopar% {
		id.info <- return.id.info(ngenes, num.work, i)
		out.loc <- .C("p_bs_miC", as.integer(ngenes), as.integer(nsamples), as.integer(binnum), as.integer(spline.order), as.integer(i), as.integer(num.work), as.double(indiv.ent), as.double(member), x=as.double(matrix(0,id.info$rows.num,ngenes)), PACKAGE="DepEst");
		mim.loc <- matrix(out.loc$x,id.info$rows.num,ngenes)
	}
	mim <- matrix(out, ngenes, ngenes)
	# make matrix mim symmetric:
	mim <- make.mim.sym(mim)
	
	if (flag==1) 
		stopCluster(cls.pr)	

	abs(mim)
}

