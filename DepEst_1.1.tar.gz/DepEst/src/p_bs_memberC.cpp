#include <R.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

extern "C"{
       void p_bs_memberC(double *, int *, int* , int* , int *, int *, int *,double *);
}

using namespace std;
void p_bs_memberC(double * datasetR, int *ngenes, int* nsamples, int* binnum, int *spline_order, int *node_ind, int *nnodes, double * member) {        

    int i, j, u, g = 0;
    int b = (*binnum), k = *spline_order, *knot;
    double x, z, sum=0,*bin_freq, *dataset, *B; //*member; 

    int nclnts=*nnodes, myid = *node_ind;
    int chunksize = (int)((*ngenes)/nclnts);
	int residual = (*ngenes)%nclnts;
    int firstcol = (myid - 1) * chunksize; 
	int lastcol = firstcol + chunksize - 1;
    if ( residual >= myid ) {
	   firstcol = firstcol + myid - 1;
	   lastcol = lastcol + myid;
	}
	else {
		firstcol = firstcol + residual;
		lastcol = lastcol + residual;
	}         


    bin_freq = new double [(*binnum)];
    dataset = new double[(lastcol-firstcol+1)*(*nsamples)];
    knot = new int[k+b];
 
    //member = new double[(*ngenes) * (*nsamples) * b];  // float member[(*ngenes)][(*nsamples)][b];
    B = new double[(b+k-1) * k];
    
    // In C, two-dimensional arrays are stored in "row-major" order, in contrast to R's "column-major" order
    for (i = 0; i < (*nsamples); i++ )
        for(j = 0; j < (lastcol-firstcol+1); j++)
              // because C is row-major, R is column-major: we don not use dataset[i][j], use dataset[j][i]
              // we do not use "(datasetR + i*(*nsamples) + j)", use "(datasetR + i*(*ngenes) + j)"
              *(dataset + j*(*nsamples) + i) = *(datasetR + i*(lastcol-firstcol+1) + j);       
               
	for(i= 0; i <(k+b); i++ )
		knot[i] = i;

                          
	// finding 3-D member array (membership values) individual entropies:   
    for(g = 0; g < (lastcol-firstcol+1); g++){          
        // find the max and min val of the samples of gene g:
        double xmax = *(dataset + g*(*nsamples) + 0); double xmin = *(dataset + g*(*nsamples) + 0);
        for (i = 1; i < (*nsamples); i++){
            if ( ( *(dataset + g*(*nsamples) + i) ) > xmax) // if (dataset[g][i] > xmax)     
                xmax = *(dataset + g*(*nsamples) + i); // dataset[g][i];                     
            if ( ( *(dataset + g*(*nsamples) + i) ) < xmin) // if (dataset[g][i] < xmin)
                xmin = *(dataset + g*(*nsamples) + i); // dataset[g][i];            
        }  
          
        for(i=0; i<b; i++)  
	        bin_freq[i] = 0;


		for (u = 0; u < (*nsamples); u++){
            
            for(i = 0; i < (b+(*spline_order)-1);  i++)
                for(j = 0; j < (*spline_order);  j++)
                    *(B + i * (*spline_order) + j) = 0; //B[i][j] = 0;
             
            x = *(dataset + g*(*nsamples) + u); //dataset[g][u]; 
            z = (x- xmin)*( (b- (*spline_order)+1.0) / (xmax-xmin) ) + (*spline_order) -1; 
            
            for(i = 0; i < (b+ (*spline_order)-1); i++ ) {
				*(B + i * (*spline_order) + 0) = 0; // B[i][0] = 0;
				if ((knot[i] <= z) && (z < knot[i+1]))
					*(B + i * (*spline_order) + 0) = 1; // B[i][0] = 1;
			}   
               
            for(i = 0; i < b; i++){
				if ( (*spline_order) > 1){				
					for (k = 1; k < (*spline_order); k++){
						if ( (knot[i+k] - knot[i]) != 0){
							if ( (knot[i+k+1] - knot[i+1]) != 0 )	
								// B[i][k] = B[i][k-1] * ( (z - knot[i]) / (knot[i+k] - knot[i]) ) + B[i+1][k-1] * ( (knot[i+k+1]-z) / (knot[i+k+1] - knot[i+1]) );
							    *(B + i * (*spline_order) + k) = *(B + i * (*spline_order) + k-1) * ( (z - knot[i]) / (knot[i+k] - knot[i]) ) + ( *(B + (i+1) * (*spline_order) + k-1) )* ( (knot[i+k+1]-z) / (knot[i+k+1] - knot[i+1]) );
                            else
								// B[i][k] = B[i][k-1] * ( (z - knot[i]) / (knot[i+k] - knot[i]) );
								*(B + i * (*spline_order) + k) = *(B + i * (*spline_order) + k-1) * ( (z - knot[i]) / (knot[i+k] - knot[i]) );
						}
						if ( (knot[i+k] - knot[i]) == 0){						
							if ( (knot[i+k+1] - knot[i+1]) != 0 )	
								// B[i][k] = B[i+1][k-1] * ( (knot[i+k+1]-z) / (knot[i+k+1] - knot[i+1]) );
								*(B + i * (*spline_order) + k) = *(B + (i+1) * (*spline_order) + k-1) * ( (knot[i+k+1]-z) / (knot[i+k+1] - knot[i+1]) );
							else
								*(B + i * (*spline_order) + k) = 0; // B[i][k] = 0;
						
						}
					}
				}
				// bin_freq[i] += B[i][(*spline_order)-1];
                bin_freq[i] += (*(B + i * (*spline_order) + (*spline_order)-1));
				// member[g][u][i] = B[i][(*spline_order)-1];			
				*(member + (g+firstcol) * (*nsamples) * b + u * b + i)  = *(B + i * (*spline_order) + (*spline_order)-1);
            }    
        }
	}	
	
    delete [ ] knot; delete [ ] bin_freq; delete [ ] dataset; delete [ ] B; //delete [ ] member; 
    
}
// int main(){return 0;}
