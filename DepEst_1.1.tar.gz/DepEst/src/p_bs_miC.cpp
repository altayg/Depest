#include <R.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

extern "C"{
       void p_bs_miC(int *, int* , int* , int *, int *, int *, double *, double *, double *);
}

using namespace std;
void p_bs_miC(int *ngenes, int* nsamples, int* binnum, int *spline_order, int *node_ind, int *nnodes, double *indiv_ent, double *member, double * mim) {        

    int i, j, u, g1, g2;
    int b = (*binnum);
    
    double joint_ent = 0.0, sum = 0.0;
      
               
	int nclnts=*nnodes, myid = *node_ind;
    int chunksize = (int)((*ngenes)/nclnts);
	int residual = (*ngenes)%nclnts;
    int firstcol = (myid - 1) * chunksize; 
	int lastcol = firstcol + chunksize - 1;
    if ( residual >= myid ) {
	   firstcol = firstcol + myid - 1;
	   lastcol = lastcol + myid;
	}
	else {
		firstcol = firstcol + residual;
		lastcol = lastcol + residual;
	}         
                                
    // finding MI of gene pairs:
	for(g1 = firstcol; g1 < (lastcol+1); g1++){
		for(g2 = (g1+1); g2 < (*ngenes); g2++){
	
			///////////////////////////////
			// joint entropy calculation //
			joint_ent = 0.0;
			for(i = 0; i < b; i++){
				for(j = 0; j < b; j++){
					sum = 0.0;
					for (u = 0; u < (*nsamples); u++)
						// sum += member[g1][u][i] * member[g2][u][j];
						sum = sum + (*(member + g1 * (*nsamples) * b + u * b + i)) * (*(member + g2 * (*nsamples) * b + u * b + j));
					sum /= (*nsamples);
					if (sum > 0)
						joint_ent = joint_ent - sum * log2(sum); // in daub et al.'s code log2 is used. (base of log is 2.)
				}
			}
			// joint entropy calculation //
			//////////////////////////////
            
            // MI(X, Y) = H(X) + H(Y) - H(X, Y)
            // *(mim + g1 * (*ngenes) + g2) = indiv_ent[g1] + indiv_ent[g2] - joint_ent;
            // *(mim + g2 * (*ngenes) + g1) = indiv_ent[g1] + indiv_ent[g2] - joint_ent;
            *(mim + g2 * (lastcol-firstcol+1) + (g1-firstcol)) = indiv_ent[g1] + indiv_ent[g2] - joint_ent;

		}
	}    
}
// int main(){return 0;}
