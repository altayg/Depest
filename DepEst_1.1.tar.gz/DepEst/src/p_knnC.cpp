#include <R.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

double digamma(int );
double digamma_recursive(int);
double digamma_old(int);

extern "C"{
       void p_knnC(double *, int *, int* , int *, int *, int *, double *);
}
using namespace std;

double p_digamma(int n)
{
	double result = -0.5772156;
	if (n > 1){
		for (int i=2 ; i<(n+1); i++){
			result += (double)1.0/(i-1.0);
		}
	}
	return result;
}

// recursive func gives the same result with the above fun. but it cannot find any result when n=1000;
double p_digamma_recursive(int n) 
{
	double result = 0.0;
	if (n <= 1)
		result = -0.5772156;
	else 
		result = p_digamma_recursive(n-1) + 1.0/(n-1.0); 
	return result;
}

double p_digamma_old(int n) 
{
	double result = 0;
	if (n > 0)
		result = log(n) - 1.0/(2.0*n);
	return result;
}


void p_knnC(double * datasetR, int *ngenes, int* nsamples, int *K, int *node_ind, int *nnodes, double * mim) {        
     
    int i, j, k,l, g1, g2, nx, ny, min_val_ind;
    double sum, min_val, xi, yi, xj, yj, knn_dist_x, knn_dist_y, *distX, *distY, *distZ;
    double *dataset;
    
    dataset = new double[(*ngenes)*(*nsamples)];
    distX = new double[(*nsamples)];
    distY = new double[(*nsamples)];
    distZ = new double[(*nsamples)];
    
    double MAX_DBL = 10000.0; 
    double digamma_of_K, digamma_of_nsamples;
    i=*K; j=*nsamples; digamma_of_K = p_digamma(i); digamma_of_nsamples = p_digamma(j);
 
     
    // In C, two-dimensional arrays are stored in "row-major" order, in contrast to R's "column-major" order
    for (i = 0; i < (*nsamples); i++ )
        for(j = 0; j < (*ngenes); j++)
              // because C is row-major, R is column-major: we don not use dataset[i][j], use dataset[j][i]
              // we do not use "(datasetR + i*(*nsamples) + j)", use "(datasetR + i*(*ngenes) + j)"
              *(dataset + j*(*nsamples) + i) = *(datasetR + i*(*ngenes) + j);       
    
    int nclnts=*nnodes, myid = *node_ind;
    int chunksize = (int)((*ngenes)/nclnts);
	int residual = (*ngenes)%nclnts;
    int firstcol = (myid - 1) * chunksize; 
	int lastcol = firstcol + chunksize - 1;
    if ( residual >= myid ) {
	   firstcol = firstcol + myid - 1;
	   lastcol = lastcol + myid;
	}
	else {
		firstcol = firstcol + residual;
		lastcol = lastcol + residual;
	}         
                                
    
    for(g1 = firstcol; g1 < (lastcol+1); g1++){
		for(g2 = (g1+1); g2 < (*ngenes); g2++){   	
			sum = 0.0;
			for(i = 0; i < (*nsamples); i++){
                for(j = 0; j < (*nsamples); j++){
                    distX[j] = MAX_DBL;   distY[j] = MAX_DBL;   distZ[j] = MAX_DBL;
                }    
				xi = *(dataset + g1 * (*nsamples) + i); // dataset[g1][i];	
				yi = *(dataset + g2 * (*nsamples) + i); // dataset[g2][i];
				for(j = 0; j < (*nsamples); j++){
                	if (i != j){
						xj = *(dataset + g1 * (*nsamples) + j); // dataset[g1][j];
					    yj = *(dataset + g2 * (*nsamples) + j); // dataset[g2][j];                        
						distX[j] = fabs(xi - xj); 
						distY[j] = fabs(yi - yj);
						distZ[j] = (double)sqrt( (xi - xj) * (xi - xj) + (yi - yj) * (yi - yj) ); 
					}
				}
				
				// sort distZ in ascending order:
                for(k =0; k < (*nsamples)-1; k++){
                    min_val = distZ[k];
                    min_val_ind = k;
                    for(l =k+1; l < (*nsamples); l++){
                        if(distZ[l] < min_val){
                            min_val = distZ[l]; 
                            min_val_ind = l;                                          
                        }
                    }
                    distZ[min_val_ind] = distZ[k];
                    distZ[k] = min_val;   
                    
                    // change distX and distY w.r.t distZ
                    double temp = distX[min_val_ind];
                    distX[min_val_ind] = distX[k];
                    distX[k] = temp;   
                    
                    temp = distY[min_val_ind];
                    distY[min_val_ind] = distY[k];
                    distY[k] = temp;                 
                }        
                        			
				knn_dist_x = distX[(*K)-1];
				knn_dist_y = distY[(*K)-1];
				
				// find nx and ny:
                nx = 0; ny = 0;
				for(k =0; k < (*nsamples); k++){
                    if(distX[k] <= knn_dist_x){  nx++; }
                        
                    if(distY[k] <= knn_dist_y){  ny++; }     
                }
				sum += (double)p_digamma(nx+1) + p_digamma(ny+1);
			}
			
			// *(mim + g1 * (*ngenes) + g2) = digamma_of_K - 1.0/(*K) - sum/(*nsamples) + digamma_of_nsamples;
			// *(mim + g2 * (*ngenes) + g1) = digamma_of_K - 1.0/(*K) - sum/(*nsamples) + digamma_of_nsamples;
			*(mim + g2 * (lastcol-firstcol+1) + (g1-firstcol)) = digamma_of_K - 1.0/(*K) - sum/(*nsamples) + digamma_of_nsamples;
		}
	}
	
}
