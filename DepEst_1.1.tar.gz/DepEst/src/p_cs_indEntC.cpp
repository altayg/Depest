#include <R.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
extern "C"{
       void p_cs_indEntC(int *, int *, int* , int* , int*, double * );
}
using namespace std;
       
void p_cs_indEntC(int * bins_of_datasetR, int *ngenes, int* nsamples, int* binnum, int *row_nums, double * indiv_ent) {        
    int i, j, g = 0, with1freq=0;
    double *bin_his_of_g;
    int *bins_of_dataset;
    
    bin_his_of_g = new double[(*binnum)];
    bins_of_dataset = new int[(*row_nums) * (*nsamples)];
             
    // In C, two-dimensional arrays are stored in "row-major" order, in contrast to R's "column-major" order
    for (i = 0; i < (*nsamples); i++ )
        for(j = 0; j < (*row_nums); j++)
              // because C is row-major, R is column-major: we don not use bins_of_dataset[i][j], use bins_of_dataset[j][i]
              // we do not use "(bins_of_datasetR + i*(*nsamples) + j)", use "(bins_of_datasetR + i*(*ngenes) + j)"
              *(bins_of_dataset + j*(*nsamples) + i)  = *(bins_of_datasetR + i*(*row_nums) + j);     
                                    
	// finding individual entropies:   
    for(g = 0; g < (*row_nums); g++){          
          for(i = 0; i < (*binnum); i++)
                bin_his_of_g[i] = 0;      
          
          // find the histogram of the bins:
          for(i = 0; i < (*nsamples); i++){
                int bin = *(bins_of_dataset + g*(*nsamples) + i); // bins_of_dataset[g][i];
                bin_his_of_g[bin-1]++;      
          }            
          
          // first, find the good-turing correction of the bin prob.s:
		  // how many bins include only one sample:
		  with1freq=0;
          for(i = 0; i < (*binnum); i++){
                if(bin_his_of_g[i] == 1)
                    with1freq++;  
          }
          
          for(i = 0; i < (*binnum); i++){
                bin_his_of_g[i] /= (*nsamples);      
          }

          for(i = 0; i < (*binnum); i++)
			    bin_his_of_g[i] = bin_his_of_g[i] * (1 - with1freq / (*nsamples) );
          
          // then, find the chao-shen entropy:
		  double sum = 0.0;	
		  for(i = 0; i < (*binnum); i++)
		        if(bin_his_of_g[i] > 0)
                    sum -= bin_his_of_g[i] * log(bin_his_of_g[i]) / (1 - pow( (1-bin_his_of_g[i]), (*nsamples) ) );	             
		            
          indiv_ent[g] = sum;
	}    
}

// int main () { return 0; }
