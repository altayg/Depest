#include <R.h>
#include <stdlib.h>
#include <cmath>
#include <stdio.h>
#include <string.h>
extern "C"{
       void p_mm_miC(int *, int *, int* , int* , int *, int *, double *, double * );
}
using namespace std;
       
void p_mm_miC(int * bins_of_datasetR, int *ngenes, int* nsamples, int* binnum, int *node_ind, int *nnodes, double *indiv_ent, double * mim) {        
    int i, j, g1, g2;
    double *bin_sq_mat, *joint_bin_his;
    int *bins_of_dataset;
    
    bin_sq_mat = new double[(*binnum) * (*binnum)];
    joint_bin_his = new double[(*binnum) * (*binnum)];
    bins_of_dataset = new int[(*ngenes) * (*nsamples)];
    
    // In C, two-dimensional arrays are stored in "row-major" order, in contrast to R's "column-major" order
    for (i = 0; i < (*nsamples); i++ )
        for(j = 0; j < (*ngenes); j++)
              // because C is row-major, R is column-major: we don not use bins_of_dataset[i][j], use bins_of_dataset[j][i]
              // we do not use "(bins_of_datasetR + i*(*nsamples) + j)", use "(bins_of_datasetR + i*(*ngenes) + j)"
              *(bins_of_dataset + j*(*nsamples) + i) = *(bins_of_datasetR + i*(*ngenes) + j);     
              
   	int nclnts=*nnodes, myid = *node_ind;
    int chunksize = (int)((*ngenes)/nclnts);
	int residual = (*ngenes)%nclnts;
    int firstcol = (myid - 1) * chunksize; 
	int lastcol = firstcol + chunksize - 1;
    if ( residual >= myid ) {
	   firstcol = firstcol + myid - 1;
	   lastcol = lastcol + myid;
	}
	else {
		firstcol = firstcol + residual;
		lastcol = lastcol + residual;
	}         
                                
    // finding MI of gene pairs:
	for(g1 = firstcol; g1 < (lastcol+1); g1++){
		for(g2 = (g1+1); g2 < (*ngenes); g2++){
               
            for (i = 0; i < (*binnum); i++ )
                for(j = 0; j < (*binnum); j++)
                      *(bin_sq_mat + i*(*binnum) + j) = 0; // bin_sq_mat[i][j] = 0;
            
			///////////////////////////////
			// joint entropy calculation //
			for (int s=0; s <(*nsamples) ; s++){
				int b1 = *(bins_of_dataset + g1 *(*nsamples) + s); // bins_of_dataset[g1][s];
				int b2 = *(bins_of_dataset + g2 *(*nsamples) + s); // bins_of_dataset[g2][s];
				(*(bin_sq_mat + (b1-1) * (*binnum) + b2-1)) += 1; // bin_sq_mat[b1-1][b2-1]++;
			}			
			
			for (i = 0; i < (*binnum); i++ )
                for(j = 0; j < (*binnum); j++)
                      joint_bin_his[i*(*binnum) + j] = *(bin_sq_mat + i*(*binnum) + j); // bin_sq_mat[i][j];
			
			for (i = 0; i < ( (*binnum) * (*binnum) ); i++ )
			    joint_bin_his[i] /= (*nsamples);	

			double sum = 0.0;
			for (int b=0; b < ( (*binnum) * (*binnum) ) ; b++){
				if (joint_bin_his[b] > 0)
					sum -= joint_bin_his[b] * log(joint_bin_his[b]);
			}

			// "H(X, Y) + bias" calculation where "bias=(number of bins without zero freq - 1) / (2*nsamples)":
			// how many bins include one or more samples:
            int without0count=0;
            for(i = 0; i < ( (*binnum) * (*binnum) ); i++){
                if(joint_bin_his[i] > 0)
                    without0count++;  
            }
            double dummy = (double)(without0count-1)/ (2.0 * (*nsamples));
            sum += dummy;
            
            // joint entropy calculation //
			///////////////////////////////

			// MI(X, Y) = H(X) + H(Y) - H(X, Y)
            // *(mim + g1 * (*ngenes) + g2) = indiv_ent[g1] + indiv_ent[g2] - sum;
            // *(mim + g2 * (*ngenes) + g1) = indiv_ent[g1] + indiv_ent[g2] - sum;
            *(mim + g2 * (lastcol-firstcol+1) + (g1-firstcol)) = indiv_ent[g1] + indiv_ent[g2] - sum;
		}
	}
    
}
//}
// int main(){ return 0; }

