#include <R.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
extern "C"{
       void chao_shenC(int *, int *, int* , int* , double * );
}
using namespace std;
       
void chao_shenC(int * bins_of_datasetR, int *ngenes, int* nsamples, int* binnum, double * mim) {        
    int i, j, g = 0, g1, g2, with1freq=0;
    double *bin_his_of_g, *bin_sq_mat, *joint_bin_his;
    int *bins_of_dataset;
    double *indiv_ent;  
   
    bin_his_of_g = new double[(*binnum)];
    bin_sq_mat = new double[(*binnum) * (*binnum)];
    joint_bin_his = new double[(*binnum) * (*binnum)];
    bins_of_dataset = new int[(*ngenes) * (*nsamples)];
    indiv_ent = new double[(*ngenes)]; 
          
    // In C, two-dimensional arrays are stored in "row-major" order, in contrast to R's "column-major" order
    for (i = 0; i < (*nsamples); i++ )
        for(j = 0; j < (*ngenes); j++)
              // because C is row-major, R is column-major: we don not use bins_of_dataset[i][j], use bins_of_dataset[j][i]
              // we do not use "(bins_of_datasetR + i*(*nsamples) + j)", use "(bins_of_datasetR + i*(*ngenes) + j)"
              *(bins_of_dataset + j*(*nsamples) + i)  = *(bins_of_datasetR + i*(*ngenes) + j);     
    
	// finding individual entropies:
	for(g = 0; g < (*ngenes); g++){
          
          for(i = 0; i < (*binnum); i++)
                bin_his_of_g[i] = 0;      
          
          // find the histogram of the bins:
          for(i = 0; i < (*nsamples); i++){
                int bin = *(bins_of_dataset + g*(*nsamples) + i); // bins_of_dataset[g][i];
                bin_his_of_g[bin-1]++;      
          }            
          
          // first, find the good-turing correction of the bin prob.s:
		  // how many bins include only one sample:
		  with1freq=0;
          for(i = 0; i < (*binnum); i++){
                if(bin_his_of_g[i] == 1)
                    with1freq++;  
          }
          
          for(i = 0; i < (*binnum); i++){
                bin_his_of_g[i] /= (*nsamples);      
          }

          for(i = 0; i < (*binnum); i++)
			    bin_his_of_g[i] = bin_his_of_g[i] * (1 - with1freq / (*nsamples) );
          
          // then, find the chao-shen entropy:
		  double sum = 0.0;	
		  for(i = 0; i < (*binnum); i++)
		        if(bin_his_of_g[i] > 0)
                    sum -= bin_his_of_g[i] * log(bin_his_of_g[i]) / (1 - pow( (1-bin_his_of_g[i]), (*nsamples) ) );	             
		            
          indiv_ent[g] = sum;
	} 

    // finding MI of gene pairs:
	for(g1 = 0; g1 < ( (*ngenes) -1); g1++){
		for(g2 = (g1+1); g2 < (*ngenes); g2++){

            for (i = 0; i < (*binnum); i++ )
                for(j = 0; j < (*binnum); j++)
                      *(bin_sq_mat + i*(*binnum) + j) = 0; // bin_sq_mat[i][j] = 0;
            
			///////////////////////////////
			// joint entropy calculation //
			for (int s=0; s <(*nsamples) ; s++){
				int b1 = *(bins_of_dataset + g1 *(*nsamples) + s); // bins_of_dataset[g1][s];
				int b2 = *(bins_of_dataset + g2 *(*nsamples) + s); // bins_of_dataset[g2][s];
				(*(bin_sq_mat + (b1-1) * (*binnum) + b2-1)) += 1; // bin_sq_mat[b1-1][b2-1]++;
			}
			
			for (i = 0; i < (*binnum); i++ )
                for(j = 0; j < (*binnum); j++)
                      joint_bin_his[i*(*binnum) + j] = *(bin_sq_mat + i*(*binnum) + j); // bin_sq_mat[i][j];

            // first, find the good-turing correction of probability of each gene pair:
			// how many bins include only one sample:
		    with1freq=0;
            for (i = 0; i < ( (*binnum) * (*binnum) ); i++ ){
                if(joint_bin_his[i] == 1)
                    with1freq++;  
            }
            
			for (i = 0; i < ( (*binnum) * (*binnum) ); i++ ){
			    joint_bin_his[i] /= (*nsamples);
			    double dummy = (double)(1 - with1freq / (*nsamples) );    
                joint_bin_his[i] *= dummy;
            }

			// then, find the chao-shen entropy:
			double sum = 0.0;	
			for (i = 0; i < ( (*binnum) * (*binnum) ); i++ )
				if(joint_bin_his[i] > 0)
					sum -= joint_bin_his[i] * log(joint_bin_his[i]) / (1 - pow( (1.0-joint_bin_his[i]), (*nsamples) ) );
			// joint entropy calculation //
			///////////////////////////////
			
			// MI(X, Y) = H(X) + H(Y) - H(X, Y)
            *(mim + g1 * (*ngenes) + g2) = indiv_ent[g1] + indiv_ent[g2] - sum;
            *(mim + g2 * (*ngenes) + g1) = indiv_ent[g1] + indiv_ent[g2] - sum;
		}
	}
}

// int main () { return 0; }
