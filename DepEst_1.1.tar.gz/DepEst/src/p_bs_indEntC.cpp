#include <R.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

extern "C"{
       void p_bs_indEntC(int *, int* , int* , int *, int *, double *,double *);
}

using namespace std;

void p_bs_indEntC(int *ngenes, int* nsamples, int* binnum, int *spline_order, int *row_nums, double * member, double * indiv_ent) {        

    int i, u, g = 0;
    int b = (*binnum), k = *spline_order;
    double sum=0,*bin_freq; //*member; 

    bin_freq = new double [(*binnum)];

	// finding individual entropies:   
    for(g = 0; g < (*row_nums); g++){          
        // find the max and min val of the samples of gene g:       
        for(i=0; i<b; i++)  
	        bin_freq[i] = 0;

		for (u = 0; u < (*nsamples); u++) 
            for(i = 0; i < b; i++)			
				bin_freq[i] += 	*(member + g * (*nsamples) * b + u * b + i);
                    
        k = *spline_order;
        sum = 0.0;
        for(i = 0; i < (*binnum); i++)
            bin_freq[i] /= (*nsamples);
            
		for(i = 0; i < b; i++)
        	if(bin_freq[i] > 0)
				sum -= bin_freq[i] * log2(bin_freq[i]);	// in daub et al.'s code log2 is used. (base of log is 2.)
		indiv_ent[g] = sum;
	}	    
}
// int main(){return 0;}
