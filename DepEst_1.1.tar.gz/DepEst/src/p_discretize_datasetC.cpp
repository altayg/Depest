#include <stdlib.h>
#include <cmath>
#include <stdio.h>
#include <string.h>
#include <R.h>
extern "C"{
       void p_discrete_datasetC(double *, int *, int* , int* , int*, int*, int* );
}
using namespace std;
void p_discrete_datasetC(double * datasetR, int *ngenes, int* nsamples, int* binnum, int*disc_method, int *row_nums, int * bins_of_dataset) {
          
    int i, j, g = 0;
    int freq, mod_nb, bin_fin; 
    double *dataset, *samples_of_g, *sorted_samples_of_g, *bin_fin_val;
    
    dataset = new double[(*row_nums)*(*nsamples)];
    samples_of_g = new double[(*nsamples)];
    sorted_samples_of_g = new double[(*nsamples)];
    bin_fin_val = new double[(*binnum)];
    
    
    // In C, two-dimensional arrays are stored in "row-major" order, in contrast to R's "column-major" order
    for (i = 0; i < (*nsamples); i++ )
        for(j = 0; j < (*row_nums); j++)
              // because C is row-major, R is column-major: we don not use dataset[i][j], use dataset[j][i]
              // we do not use "(datasetR + i*(*nsamples) + j)", use "(datasetR + i*(*ngenes) + j)"
              *(dataset + j*(*nsamples) + i) = *(datasetR + i*(*row_nums) + j);       
               
    
    // 1 for Equal frequency discr method:
    //if (strcmp(disc_method, "eq.freq") == 0){
    if ( (*disc_method) == 1){    
       //printf("Equal freq \n");
       for (g = 0; g < (*row_nums); g++){
           for(i =0; i < (*nsamples); i++)
                 samples_of_g[i] = *(dataset + g*(*nsamples) + i); // dataset[g][i];

           for(i =0; i < (*nsamples); i++)
                 sorted_samples_of_g[i] = samples_of_g[i];
                 
           freq = (int)trunc((*nsamples) / (*binnum) );
           mod_nb = (*nsamples) % (*binnum);
           bin_fin = freq-1;
           for(i =0; i < (*binnum); i++)
                 bin_fin_val[i] = 0;
           
           // sort the array samples_of_g in the ascending order:
           for(i =0; i < (*nsamples)-1; i++){
                 double min_val = sorted_samples_of_g[i];
                 int min_val_ind = i;
                 for(j =i+1; j < (*nsamples); j++){
                       if(sorted_samples_of_g[j] < min_val){
                           min_val = sorted_samples_of_g[j]; 
                           min_val_ind = j;                                          
                       }
                 }
                 sorted_samples_of_g[min_val_ind] = sorted_samples_of_g[i];
                 sorted_samples_of_g[i] = min_val;                 
           }

           for(i =0; i < (*binnum)-1; i++){
                 if (mod_nb > 0){
                     bin_fin++;
                     bin_fin_val[i] = sorted_samples_of_g[bin_fin];
					 mod_nb--;
		         }	
			     else
			         bin_fin_val[i] = sorted_samples_of_g[bin_fin];
				 bin_fin += freq;
			}
                 
            bin_fin_val[(*binnum)-1] = sorted_samples_of_g[(*nsamples)-1] + 0.05;
            for(int s =0; s < (*nsamples); s++){
				int bin = -1, k = 0;
				while(k < (*binnum) && bin == -1){
					if(samples_of_g[s] <= bin_fin_val[k])	bin = k+1;
					k++;
				}
				// because C is row-major, R is column-major, do not use "*(bins_of_dataset + g * (*nsamples) + s)" :
				*(bins_of_dataset + s * (*row_nums) + g) = bin;
			}     
       }
    }
    
    // 2 for Equal width discr method:
	// else if (strcmp(disc_method, "eq.wid") == 0){
    else if ( (*disc_method) == 2){
        // printf("Equal wid \n");
        for (g = 0; g < (*row_nums); g++){
            for(i =0; i < (*nsamples); i++)
                 samples_of_g[i] = *(dataset + g*(*nsamples) + i); // dataset[g][i];

            // find the max and min val of the samples_of_g:
            double max_of_g = samples_of_g[0], min_of_g = samples_of_g[0];
            for (i = 1; i < (*nsamples); i++){
                if (samples_of_g[i] > max_of_g)
                   max_of_g = samples_of_g[i];                     
                if (samples_of_g[i] < min_of_g)
                   min_of_g = samples_of_g[i];            
            }      
			double binwidth = (max_of_g - min_of_g)/(*binnum);
			for(int s =0; s < (*nsamples); s++){
				int bin = 0;
				while ( (binwidth != 0) && !( (*(dataset + g*(*nsamples) + s))>=(min_of_g+bin*binwidth) && (*(dataset + g*(*nsamples) + s))< (min_of_g+(bin+1)*binwidth) ) )
					bin++;
				if (bin == (*binnum))	bin = (*binnum)-1;	
				// because C is row-major, R is column-major, do not use "*(bins_of_dataset + g * (*nsamples) + s)" :
				*(bins_of_dataset + s * (*row_nums) + g) = bin + 1;				
			}			
		}
	}  
    
}
//}

//int main () { return 0; }
