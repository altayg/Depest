#include <R.h>
#include <stdlib.h>
#include <cmath>
#include <stdio.h>
#include <string.h>
extern "C"{
       void p_mm_indEntC(int *, int *, int* , int* , int *, double * );
}
using namespace std;
       
void p_mm_indEntC(int * bins_of_datasetR, int *ngenes, int* nsamples, int* binnum, int *row_nums, double * indiv_ent) {        
    int i, j, g = 0;
    double *bin_his_of_g;
    int *bins_of_dataset;
        
    bin_his_of_g = new double[(*binnum)];
    bins_of_dataset = new int[(*row_nums) * (*nsamples)];
    
    // In C, two-dimensional arrays are stored in "row-major" order, in contrast to R's "column-major" order
    for (i = 0; i < (*nsamples); i++ )
        for(j = 0; j < (*row_nums); j++)
              // because C is row-major, R is column-major: we don not use bins_of_dataset[i][j], use bins_of_dataset[j][i]
              // we do not use "(bins_of_datasetR + i*(*nsamples) + j)", use "(bins_of_datasetR + i*(*ngenes) + j)"
              *(bins_of_dataset + j*(*nsamples) + i) = *(bins_of_datasetR + i*(*row_nums) + j);     
              
	// finding individual entropies:   
    for(g = 0; g < (*row_nums); g++){                     
          for(i = 0; i < (*binnum); i++)
                bin_his_of_g[i] = 0;      
          
          // find the histogram of the bins:
          for(i = 0; i < (*nsamples); i++){
                int bin = *(bins_of_dataset + g*(*nsamples) + i); //bins_of_dataset[g][i]; 
                bin_his_of_g[bin-1]++;      
          }
          for(i = 0; i < (*binnum); i++){
                bin_his_of_g[i] /= (*nsamples);      
          }
          double sum = 0.0;
          for(i = 0; i < (*binnum); i++){
                if(bin_his_of_g[i] > 0){
                    sum -= bin_his_of_g[i] * log(bin_his_of_g[i]);  // log natural (base e) is used in minet and james-stein shrink (log2 is not used!)                  
                }      
          }
          
          // "H(X) + bias" calculation where "bias=(number of bins without zero freq - 1) / (2*nsamples)":
		  // how many bins include one or more samples:
          int without0count=0;
          for(i = 0; i < (*binnum); i++){
                if(bin_his_of_g[i] > 0)
                    without0count++;  
          }
          double dummy = (double)(without0count-1.0)/ (2.0 * (*nsamples));
          sum += dummy;
          indiv_ent[g] = sum;
	}
    
}
//}
// int main(){ return 0; }

