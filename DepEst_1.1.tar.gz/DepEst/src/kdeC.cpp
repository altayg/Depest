#include <R.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
extern "C"{
       void kdeC(double *, int *, int* , double * , double * );
}
using namespace std;
         
void kdeC(double * datasetR, int *ngenes, int* nsamples, double * bandwidth, double * mim) {        
     
    int i, j, k, g1, g2;
    double sumX, sumY, sumXY, mim_xy, xi, yi, xj, yj;
    double * dataset;

    dataset = new double[(*ngenes)*(*nsamples)];
        
    double h = 0.525 * (double) (pow( (*nsamples), -0.24)); // suggested in the supp.doc.
    if ((*bandwidth) > 0) h = (*bandwidth);

    double div_val = (2.0*h*h);
    double dummy_log;
    
    // In C, two-dimensional arrays are stored in "row-major" order, in contrast to R's "column-major" order
    for (i = 0; i < (*nsamples); i++ )
        for(j = 0; j < (*ngenes); j++)
              // because C is row-major, R is column-major: we don not use dataset[i][j], use dataset[j][i]
              // we do not use "(datasetR + i*(*nsamples) + j)", use "(datasetR + i*(*ngenes) + j)"
              *(dataset + j*(*nsamples) + i) = *(datasetR + i*(*ngenes) + j);       
    
    
    for(g1 = 0; g1 < ( (*ngenes) -1); g1++){
		for(g2 = (g1+1); g2 < (*ngenes); g2++){   	
			mim_xy = 0.0;
			for(i = 0; i < (*nsamples); i++){
				xi = *(dataset + g1 * (*nsamples) + i); // dataset[g1][i];	
				yi = *(dataset + g2 * (*nsamples) + i); // dataset[g2][i];
				sumX = 0.0; sumY = 0.0; sumXY = 0.0;	
				for(j = 0; j < (*nsamples); j++){
					xj = *(dataset + g1 * (*nsamples) + j); // dataset[g1][j];
					yj = *(dataset + g2 * (*nsamples) + j); // dataset[g2][j];
					sumX += (double)exp(- pow( (double) (xi-xj), 2.0) /div_val);
					sumY += (double)exp(- pow( (double) (yi-yj), 2.0) /div_val);
					sumXY += (double)exp(- ( pow( (double) (xi-xj), 2.0) + pow( (double) (yi-yj), 2.0) ) /div_val);				
				}
				dummy_log = (double)(*nsamples) * sumXY / (sumX * sumY);
				if (dummy_log != 0) dummy_log = log(dummy_log); 
				mim_xy += dummy_log;
			}			
			*(mim + g1 * (*ngenes) + g2) = mim_xy / (*nsamples);
			*(mim + g2 * (*ngenes) + g1) = mim_xy / (*nsamples);
			
		}
	}	
}
// int main(){ return 0; }

