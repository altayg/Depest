#include <R.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

extern "C"{
       void b_splineC(double *, int *, int* , int* , int *, double *);
}

using namespace std;
void b_splineC(double * datasetR, int *ngenes, int* nsamples, int* binnum, int *spline_order, double * mim) {        


    int i, j, u, g = 0, g1, g2;
    int b = (*binnum), k = *spline_order, *knot;
    double x, z, *bin_freq, *dataset, *indiv_ent, *member, *B; 

    bin_freq = new double [(*binnum)];
    dataset = new double[(*ngenes)*(*nsamples)];
    indiv_ent = new double[(*ngenes)];
    knot = new int[k+b];
 
    member = new double[(*ngenes) * (*nsamples) * b];  // float member[(*ngenes)][(*nsamples)][b];
    B = new double[(b+k-1) * k];
    
    double joint_ent = 0.0, sum = 0.0;

    // In C, two-dimensional arrays are stored in "row-major" order, in contrast to R's "column-major" order
    for (i = 0; i < (*nsamples); i++ )
        for(j = 0; j < (*ngenes); j++)
              // because C is row-major, R is column-major: we don not use dataset[i][j], use dataset[j][i]
              // we do not use "(datasetR + i*(*nsamples) + j)", use "(datasetR + i*(*ngenes) + j)"
              *(dataset + j*(*nsamples) + i) = *(datasetR + i*(*ngenes) + j);       
               

	for(i= 0; i <(k+b); i++ )
		knot[i] = i;

	// finding individual entropies:
	for(g = 0; g < (*ngenes); g++){
        // find the max and min val of the samples of gene g:
        double xmax = *(dataset + g*(*nsamples) + 0); double xmin = *(dataset + g*(*nsamples) + 0);
        for (i = 1; i < (*nsamples); i++){
            if ( ( *(dataset + g*(*nsamples) + i) ) > xmax) // if (dataset[g][i] > xmax)     
                xmax = *(dataset + g*(*nsamples) + i); // dataset[g][i];                     
            if ( ( *(dataset + g*(*nsamples) + i) ) < xmin) // if (dataset[g][i] < xmin)
                xmin = *(dataset + g*(*nsamples) + i); // dataset[g][i];            
        }  
          
        for(i=0; i<b; i++)  
	        bin_freq[i] = 0;


		for (u = 0; u < (*nsamples); u++){
            
            for(i = 0; i < (b+(*spline_order)-1);  i++)
                for(j = 0; j < (*spline_order);  j++)
                    *(B + i * (*spline_order) + j) = 0; //B[i][j] = 0;
             
            x = *(dataset + g*(*nsamples) + u); //dataset[g][u]; 
            z = (x- xmin)*( (b- (*spline_order)+1.0) / (xmax-xmin) ) + (*spline_order) -1; 
            
            for(i = 0; i < (b+ (*spline_order)-1); i++ ) {
				*(B + i * (*spline_order) + 0) = 0; // B[i][0] = 0;
				if ((knot[i] <= z) && (z < knot[i+1]))
					*(B + i * (*spline_order) + 0) = 1; // B[i][0] = 1;
			}   
               
            for(i = 0; i < b; i++){
				if ( (*spline_order) > 1){				
					for (k = 1; k < (*spline_order); k++){
						if ( (knot[i+k] - knot[i]) != 0){
							if ( (knot[i+k+1] - knot[i+1]) != 0 )	
								// B[i][k] = B[i][k-1] * ( (z - knot[i]) / (knot[i+k] - knot[i]) ) + B[i+1][k-1] * ( (knot[i+k+1]-z) / (knot[i+k+1] - knot[i+1]) );
							    *(B + i * (*spline_order) + k) = *(B + i * (*spline_order) + k-1) * ( (z - knot[i]) / (knot[i+k] - knot[i]) ) + ( *(B + (i+1) * (*spline_order) + k-1) )* ( (knot[i+k+1]-z) / (knot[i+k+1] - knot[i+1]) );
                            else
								// B[i][k] = B[i][k-1] * ( (z - knot[i]) / (knot[i+k] - knot[i]) );
								*(B + i * (*spline_order) + k) = *(B + i * (*spline_order) + k-1) * ( (z - knot[i]) / (knot[i+k] - knot[i]) );
						}
						if ( (knot[i+k] - knot[i]) == 0){						
							if ( (knot[i+k+1] - knot[i+1]) != 0 )	
								// B[i][k] = B[i+1][k-1] * ( (knot[i+k+1]-z) / (knot[i+k+1] - knot[i+1]) );
								*(B + i * (*spline_order) + k) = *(B + (i+1) * (*spline_order) + k-1) * ( (knot[i+k+1]-z) / (knot[i+k+1] - knot[i+1]) );
							else
								*(B + i * (*spline_order) + k) = 0; // B[i][k] = 0;
						
						}
					}
				}
				// bin_freq[i] += B[i][(*spline_order)-1];
                bin_freq[i] += (*(B + i * (*spline_order) + (*spline_order)-1));
				// member[g][u][i] = B[i][(*spline_order)-1];			
				*(member + g * (*nsamples) * b + u * b + i)  = *(B + i * (*spline_order) + (*spline_order)-1);
            }    
        }
        k = *spline_order;
        sum = 0.0;
        for(i = 0; i < (*binnum); i++)
            bin_freq[i] /= (*nsamples);
            
		for(i = 0; i < b; i++)
        	if(bin_freq[i] > 0)
				sum -= bin_freq[i] * log2(bin_freq[i]);	// in daub et al.'s code log2 is used. (base of log is 2.)
		indiv_ent[g] = sum;
	}	
	
    // finding MI of gene pairs:
	for(g1 = 0; g1 < ( (*ngenes) -1); g1++){
		for(g2 = (g1+1); g2 < (*ngenes); g2++){
	
			///////////////////////////////
			// joint entropy calculation //
			joint_ent = 0.0;
			for(i = 0; i < b; i++){
				for(j = 0; j < b; j++){
					sum = 0.0;
					for (u = 0; u < (*nsamples); u++)
						// sum += member[g1][u][i] * member[g2][u][j];
						sum = sum + (*(member + g1 * (*nsamples) * b + u * b + i)) * (*(member + g2 * (*nsamples) * b + u * b + j));
					sum /= (*nsamples);
					if (sum > 0)
						joint_ent = joint_ent - sum * log2(sum); // in daub et al.'s code log2 is used. (base of log is 2.)
				}
			}
			// joint entropy calculation //
			//////////////////////////////
            
            // MI(X, Y) = H(X) + H(Y) - H(X, Y)
            *(mim + g1 * (*ngenes) + g2) = indiv_ent[g1] + indiv_ent[g2] - joint_ent;
            *(mim + g2 * (*ngenes) + g1) = indiv_ent[g1] + indiv_ent[g2] - joint_ent;
		}
	}
	
    delete [ ] knot; delete [ ] bin_freq; delete [ ] dataset; delete [ ] indiv_ent, delete [ ] member, delete [ ] B; 
    
}
// int main(){return 0;}
