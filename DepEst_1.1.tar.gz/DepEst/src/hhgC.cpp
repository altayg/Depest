#include <R.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
extern "C"{
       void hhgC(double * , int *, int* , double * );
}
using namespace std;

void hhgC(double * datasetR, int *ngenes, int* nsamples, double * mim) {        


    int i, j, k, g1, g2, A11 = 0, A12 = 0, A21 = 0, A22 = 0, A1n, A2n, An1, An2;
    double T, Sij, xi, yi, xj, yj, xk, yk, distX, distY;
    double *dataset;
    
    dataset = new double[(*ngenes)*(*nsamples)];
        
    // In C, two-dimensional arrays are stored in "row-major" order, in contrast to R's "column-major" order
    for (i = 0; i < (*nsamples); i++ )
        for(j = 0; j < (*ngenes); j++)
              // because C is row-major, R is column-major: we don not use dataset[i][j], use dataset[j][i]
              // we do not use "(datasetR + i*(*nsamples) + j)", use "(datasetR + i*(*ngenes) + j)"
              *(dataset + j*(*nsamples) + i) = *(datasetR + i*(*ngenes) + j);       
    
    for(g1 = 0; g1 < ( (*ngenes) -1); g1++){
		for(g2 = (g1+1); g2 < (*ngenes); g2++){
			T = 0.0;
			for(i = 0; i < (*nsamples); i++){
				xi = *(dataset + g1 * (*nsamples) + i); // dataset[g1][i];	
				yi = *(dataset + g2 * (*nsamples) + i); // dataset[g2][i];
				for(j = 0; j < (*nsamples); j++){
					xj = *(dataset + g1 * (*nsamples) + j); // dataset[g1][j];
					yj = *(dataset + g2 * (*nsamples) + j); // dataset[g2][j];
					if(i != j){
						distX = fabs(xi-xj);     distY = fabs(yi-yj);
						A11 = 0; 	A12 = 0;     A21 = 0;      A22 = 0;
						for(k = 0; k < (*nsamples); k++){		
							if( (k != i) && (k != j) ){
								xk = *(dataset + g1 * (*nsamples) + k); // dataset[g1][k];	
                                yk = *(dataset + g2 * (*nsamples) + k); // dataset[g2][k];
								if( (fabs(xi-xk) <= distX) && (fabs(yi-yk) <= distY) ) A11++;
								if( (fabs(xi-xk) <= distX) && (fabs(yi-yk) > distY) )  A12++;	
								if( (fabs(xi-xk) > distX) && (fabs(yi-yk) <= distY) )  A21++;
								if( (fabs(xi-xk) > distX) && (fabs(yi-yk) > distY) )   A22++;	
							}
						}
						A1n = A11 + A12; A2n = A21 + A22; An1 = A11 + A21; An2 = A12 + A22;
						Sij = 0.0;	
						if ( (A1n*A2n*An1*An2) != 0 )
							Sij = (double)( (*nsamples) - 2.0)*(A12*A21 - A11*A22)*(A12*A21 - A11*A22) / (A1n*A2n*An1*An2);
						T += Sij;
					}
				}
			}
			*(mim + g1 * (*ngenes) + g2) = T;
			*(mim + g2 * (*ngenes) + g1) = T;
		}
	}
	
}

// int main(){ return 0; }
